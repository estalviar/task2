package com.company;

import java.io.*;
import java.sql.*;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        try {
            Class.forName("org.h2.Driver");

            String db_name = "db";

            Connection conn = DriverManager.getConnection( "jdbc:h2:./" + db_name, "sa", "" );

            // Call it to create db
            // createTable(conn);

            Statement q = conn.createStatement();

            ResultSet r = q.executeQuery( "select * from tree;" );

            Tree t = new Tree();

            while (r.next())
                t.add( r.getInt("id" ), r.getInt( "parent" ) );

            conn.close();

            List<Node> roots = t.getRoots();

            for( int i = 0; i < roots.size(); i++ )
                System.out.println( roots.get(i).getId());
        } catch (ClassNotFoundException e) {
            System.out.println( "Error: " + e.getMessage() );
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println( "SQL error: " + e.getMessage() );
        } catch (Exception e) {
            System.out.println( "Error: " + e.getMessage() );
        }
    }

    static void analyze(Tree t) throws Exception {
        List<Node> roots = t.getRoots();

        int max, maxid, maxcnt, cnt;

        max = 0;
        maxid = 0;
        maxcnt = 0;

        for( int i = 0; i < roots.size(); i++ )
        {
            cnt = roots.get(i).leafCount();

            if (cnt > max)
            {
                max = cnt;
                maxid = roots.get(i).getId();
                maxcnt = 1;
            }
            else if (cnt == max)
                maxcnt++;
        }

        /* if (maxcnt > 1)
            throw new Exception( "to many threes" ); // */

        FileWriter wr = new FileWriter( "output.txt" );

        if (maxcnt != 1)
            wr.write( "0,0\n" );
        else
            wr.write( maxid + "," + max + "\n" );

        wr.close();
    }

    // Initialize db and fill it with data
    public static void createTable(Connection conn) throws SQLException, IOException {
        Statement q = conn.createStatement();

        ResultSet r;

        q.execute( "create table tree( id int, parent int );" );

        BufferedReader reader = new BufferedReader(new FileReader("input.csv"));

        while (true)
        {
            String line = reader.readLine();
            if (line == null)
                break;
            String[] col = line.split( "," );
            if (col.length < 2)
                break;

            q.execute( "insert into tree (id, parent) values (" + col[0] + ", " + col[1] + ");" );
        }

        reader.close();
    }
}
