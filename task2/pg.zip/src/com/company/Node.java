package com.company;

import java.util.ArrayList;
import java.util.List;

public class Node {
    int id, parent_id;
    Node parent;
    List<Node> child = new ArrayList<>();

    public Node( int _id, int _parent )
    {
        id = _id;
        parent_id = _parent;
    }
    public boolean isLeaf()
    {
        return child.size() == 0;
    }

    public boolean isRoot()
    {
        return parent == null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParent_id() {
        return parent_id;
    }

    public void setParent_id(int parent_id) {
        this.parent_id = parent_id;
    }

    public Node getParent() {
        return parent;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public List<Node> getChild() {
        return child;
    }

    public int leafCount()
    {
        if (isLeaf())
            return 1;

        int s = 0;

        for( int i = 0; i < child.size(); i++ )
            s += child.get(i).leafCount();

        return s;
    }
}
